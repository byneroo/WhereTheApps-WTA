﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace HideDesktop
{
    static class Program
    {
        // WinAPI
        private const int SW_HIDE = 0;
        private const int SW_SHOW = 5;
        private const uint SMTO_NORMAL = 0x0000;
        private const int WM_USER = 0x0400;
        private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);

        private const int WM_HOTKEY = 0x0312;
        private const int HOTKEY_ID = 0xA000; // arbitrary

        // Progman message (used in some desktop enumerations)
        private const uint WM_SPAWN_WORKER = 0x052C;

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindowEx(IntPtr parentHandle, IntPtr childAfter, string lclassName, string windowTitle);

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out IntPtr lpdwResult);

        [DllImport("user32.dll")]
        static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        static bool iconsHidden = false;
        static IntPtr desktopListView = IntPtr.Zero;
        static IntPtr taskbarHwnd = IntPtr.Zero;

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Find handles initially
            desktopListView = FindDesktopListView();
            taskbarHwnd = FindWindow("Shell_TrayWnd", null);

            using (var ctx = new HotkeyApplicationContext())
            {
                Application.Run(ctx);
            }
        }

        // Tries to locate the SysListView32 handle that holds desktop icons
        static IntPtr FindDesktopListView()
        {
            // 1) Try Progman -> SHELLDLL_DefView -> SysListView32
            IntPtr progman = FindWindow("Progman", null);
            if (progman != IntPtr.Zero)
            {
                IntPtr defView = FindWindowEx(progman, IntPtr.Zero, "SHELLDLL_DefView", null);
                if (defView != IntPtr.Zero)
                {
                    IntPtr listView = FindWindowEx(defView, IntPtr.Zero, "SysListView32", "FolderView");
                    if (listView != IntPtr.Zero) return listView;
                }
            }

            // 2) If not found, send message to Progman to spawn WorkerW and then enumerate WorkerW windows
            if (progman != IntPtr.Zero)
            {
                IntPtr result;
                SendMessageTimeout(progman, WM_SPAWN_WORKER, IntPtr.Zero, IntPtr.Zero, SMTO_NORMAL, 1000, out result);
            }

            IntPtr found = IntPtr.Zero;
            EnumWindows((hWnd, lParam) =>
            {
                StringBuilder cls = new StringBuilder(256);
                GetClassName(hWnd, cls, cls.Capacity);
                if (cls.ToString() == "WorkerW")
                {
                    // inside WorkerW look for SHELLDLL_DefView
                    IntPtr def = FindWindowEx(hWnd, IntPtr.Zero, "SHELLDLL_DefView", null);
                    if (def != IntPtr.Zero)
                    {
                        IntPtr lv = FindWindowEx(def, IntPtr.Zero, "SysListView32", "FolderView");
                        if (lv != IntPtr.Zero)
                        {
                            found = lv;
                            return false; // stop enumeration
                        }
                    }
                }
                return true;
            }, IntPtr.Zero);

            return found;
        }

        // Toggle both desktop icons and taskbar
        static void Toggle()
        {
            // Refresh handles if needed
            if (desktopListView == IntPtr.Zero || !IsWindowValid(desktopListView))
            {
                desktopListView = FindDesktopListView();
            }
            if (taskbarHwnd == IntPtr.Zero || !IsWindowValid(taskbarHwnd))
            {
                taskbarHwnd = FindWindow("Shell_TrayWnd", null);
            }

            iconsHidden = !iconsHidden;

            if (desktopListView != IntPtr.Zero)
            {
                ShowWindow(desktopListView, iconsHidden ? SW_HIDE : SW_SHOW);
            }

            if (taskbarHwnd != IntPtr.Zero)
            {
                ShowWindow(taskbarHwnd, iconsHidden ? SW_HIDE : SW_SHOW);
            }
        }

        static bool IsWindowValid(IntPtr h)
        {
            return h != IntPtr.Zero;
        }

        // ApplicationContext that registers hotkey and receives messages
        class HotkeyApplicationContext : ApplicationContext
        {
            private MessageWindow msgWindow;

            public HotkeyApplicationContext()
            {
                msgWindow = new MessageWindow();
                // Register Pause/Break key (VK_PAUSE = 0x13), no modifiers
                const uint VK_PAUSE = 0x13;
                if (!RegisterHotKey(msgWindow.Handle, HOTKEY_ID, 0, VK_PAUSE))
                {
                    MessageBox.Show("Hotkey register failed. Make sure another program isn't using Pause/Break.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Optional: create a tray icon so user can exit
                var ni = new NotifyIcon()
                {
                    Visible = true,
                    Text = "HideDesktop (Pause toggles)",
                    Icon = SystemIcons.Application,
                    ContextMenu = new ContextMenu(new MenuItem[]
                    {
                        new MenuItem("Exit", (s,e) => ExitThread())
                    })
                };
            }

            protected override void Dispose(bool disposing)
            {
                UnregisterHotKey(msgWindow.Handle, HOTKEY_ID);
                msgWindow.Dispose();
                base.Dispose(disposing);
            }

            private void ExitThread()
            {
                Application.Exit();
            }
        }

        // hidden window that processes WM_HOTKEY
        class MessageWindow : NativeWindow, IDisposable
        {
            private const string className = "HiddenMessageWindow_HideDesktopExample";

            public MessageWindow()
            {
                CreateHandle(new CreateParams()
                {
                    Caption = className,
                    ClassName = null,
                    X = 0,
                    Y = 0,
                    Height = 0,
                    Width = 0,
                    Style = 0x800000 // WS_VISIBLE (not really shown)
                });
            }

            protected override void WndProc(ref Message m)
            {
                if (m.Msg == WM_HOTKEY)
                {
                    // toggle on hotkey
                    Toggle();
                }
                base.WndProc(ref m);
            }

            public void Dispose()
            {
                DestroyHandle();
            }
        }
    }
}
